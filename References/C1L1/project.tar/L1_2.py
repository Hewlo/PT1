i = open('sample_input.txt', 'r')
o = open('sample_output.txt', 'w')

a = i.read()
print(i.read())

o.write(a)
print(a)
